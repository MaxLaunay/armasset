configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory = $true)][string]$adDomainName,
        [Parameter(Mandatory = $true)][string]$password 
    ) 
    
    Import-DscResource -ModuleName xNetworking

    Node localhost
    {
        # restart the node as soon as the configuration has been completely applies, without further warning
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        
        # Disable Automatic Update
        Registry UpdateTurnOff
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
            ValueName = "NoAutoUpdate"
            ValueData = "1"
            ValueType = "DWORD"

        }
        
        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }
        
        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = 'Ethernet'
            AddressFamily  = 'IPv4'
        }
        
        WindowsFeature ADDS
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
        }  
        # Enable Active Directory Deployment Module
        
        Script ADModule
        {
            setSCript = 'Import-Module ADDSDeployment'
            TestScript = 'if(Get-Module ADDSDeployment){return $True}else{return $False}'
            GetScript = 'if(Get-Module ADDSDeployment){@("Present")}else{@("Absent")}'
            DependsOn = "[WindowsFeature]ADDS"
        }

        # Create Active Directory
        Script ADInstallation
        { 
            setSCript = 'Install-ADDSForest `
                    -CreateDnsDelegation:$false `
                    -DatabasePath "C:\Windows\NTDS" `
                    -DomainMode "Win2012R2" `
                    -DomainName "' + $ADdomainName + '" `
                    -DomainNetbiosName "' + $ADdomainName.split('.')[0] +  '" `
                    -ForestMode "Win2012R2" `
                    -InstallDns:$true `
                    -LogPath "C:\Windows\NTDS"  `
                    -NoRebootOnCompletion:$false `
                    -SysvolPath "C:\Windows\SYSVOL" `
                    -SafeModeAdministratorPassword (convertto-securestring "' + $password + '" -asplaintext -force) -Force:$true'
            TestScript = 'try{if(Get-ADDomainController){return $True}else{return $False}}catch{ return $False}'
            GetScript = 'try{if(Get-ADDomainController){return @("Present")}else{return @("Absent")}}catch{ return $False}'
            DependsOn = @("[WindowsFeature]ADDS","[Script]ADModule")
        }
   }
} 

Configuration ActiveDirectory {

    Param (
        [Parameter(Mandatory = $true)][string]$password,
        [Parameter(Mandatory = $true)][string]$adDomainName,
        [Parameter(Mandatory = $true)][string]$domainNetbiosName
    )

    Import-DscResource -ModuleName xNetworking

    Node "localhost"
    {
        # restart the node as soon as the configuration has been completely applies, without further warning
        LocalConfigurationManager
            {
                RebootNodeIfNeeded = $true
            }

        # Disable Automatic Update
        Registry UpdateTurnOff
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
            ValueName = "NoAutoUpdate"
            ValueData = "1"
            ValueType = "DWORD"

        }

        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }
        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = 'Ethernet'
            AddressFamily  = 'IPv4'
        }

        # Install Active Directory Features
        WindowsFeature ADDS
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }

        # Enable Active Directory Deployment Module
        Script ADModule
        {
            setSCript = 'Import-Module ADDSDeployment'
            TestScript = 'if(Get-Module ADDSDeployment){return $True}else{return $False}'
            GetScript = 'if(Get-Module ADDSDeployment){@("Present")}else{@("Absent")}'
            DependsOn = "[WindowsFeature]ADDS"
        }

        # Create Active Directory
        Script ADInstallation
        { 
            setSCript = 'Install-ADDSForest `
                    -CreateDnsDelegation:$false `
                    -DatabasePath "C:\Windows\NTDS" `
                    -DomainMode "Win2012R2" `
                    -DomainName "' + $ADdomainName + '" `
                    -DomainNetbiosName "' + $DomainNetbiosName +  '" `
                    -ForestMode "Win2012R2" `
                    -InstallDns:$true `
                    -LogPath "C:\Windows\NTDS"  `
                    -NoRebootOnCompletion:$false `
                    -SysvolPath "C:\Windows\SYSVOL" `
                    -SafeModeAdministratorPassword (convertto-securestring "' + $password + '" -asplaintext -force) -Force:$true'
            TestScript = 'try{if(Get-ADDomainController){return $True}else{return $False}}catch{ return $False}'
            GetScript = 'try{if(Get-ADDomainController){return @("Present")}else{return @("Absent")}}catch{ return $False}'
            DependsOn = @("[WindowsFeature]ADDS","[Script]ADModule")
        }
    }

}

Configuration SQLServerold {
    Param (
        [Parameter(Mandatory = $true)][string]$username,
        [Parameter(Mandatory = $true)][String]$password,
        [Parameter(Mandatory = $true)][string]$databaseName,
        [Parameter(Mandatory = $true)][string]$ADdomainName,
        [Parameter(Mandatory = $true)][string]$SQLSetupConfigurationFileUri,
        [Parameter(Mandatory = $true)][string]$SQLServerISOUri,
        [Parameter(Mandatory = $true)][string]$SQLDatabaseFileUri
    )
    Node "localhost"
    {
        # restart the node as soon as the configuration has been completely applies, without further warning
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        
        # Disable Automatic Update
        Registry UpdateTurnOff
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
            ValueName = "NoAutoUpdate"
            ValueData = "1"
            ValueType = "DWORD"

        }
        
        # Add computer to Active Directory
        Script SetAD
        {
            setSCript = '$pass =  "'+ $password +'" | ConvertTo-SecureString -asPlainText -Force ;
                $user = "'+ $ADdomainName +'\' + $username + '" ;
                $credential = New-Object System.Management.Automation.PSCredential($user,$pass);
                Add-Computer -DomainName ' + $ADdomainName + ' -Credential $credential'
            TestScript = 'if ((Get-WmiObject Win32_ComputerSystem).domain -eq "'+ $ADdomainName +'"){return $True}else{return $false}'
            GetScript = '@((Get-WmiObject Win32_ComputerSystem).domain)'
        }
        
        # create a source folder before upload configuration files and SQL Server ISO
        File SourcesFolder
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = "C:\sources"    
        }
        
        Script ConfigurationFile
        {
            setSCript = '
                $source = "' + $SQLSetupConfigurationFileUri + '" ;
                $destination = "c:\sources\ConfigurationFile.ini" ;
                (new-object system.net.webclient).DownloadFile($source,$destination)'
            TestScript = 'Test-Path "c:\sources\ConfigurationFile.ini"'
            GetScript = 'if (Test-Path "c:\sources\ConfigurationFile.ini"){return @("Present")}else{return @("Absent")}'
            DependsOn = "[File]SourcesFolder"
        }
        
        # get SLQ Server 2012 Express
        Script SQLServerDownload
        {
            setSCript = '$source = "' + $SQLServerISOUri + '" ;
                $destination = "c:\sources\SQLFULL_ENU.iso" ;
                (new-object system.net.webclient).DownloadFile($source,$destination)'
            TestScript = 'Test-Path c:\sources\SQLFULL_ENU.iso'
            GetScript = 'if (Test-Path c:\sources\SQLFULL_ENU.iso){return @("Present")}else{return @("Absent")}'
            DependsOn = @("[File]SourcesFolder","[Script]SetAD")
        }

        # Mount ISO
        Script MountISO
        {
            setSCript = 'Mount-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso ; start-sleep 10'
            TestScript = '(Get-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso).Attached'
            GetScript = '
                if((Get-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso).Attached){
                    return @("Present")
                }else{
                    return @("Absent")'
            DependsOn = "[Script]SQLServerDownload"
        }

       # Install SQL Server
        Script SQLServerInstallation
        {
            setSCript = '$driverletter = ((get-Volume -DiskImage (Get-DiskImage -ImagePath "c:\sources\SQLFULL_ENU.iso")).DriveLetter) + ":" ;
                $cmd = "$driverletter\Setup.exe /Q /IACCEPTSQLSERVERLICENSETERMS /ACTION=install /ConfigurationFile=c:\sources\ConfigurationFile.ini" ;
                $cmd += " /SQLSYSADMINACCOUNTS=' + $ADdomainName + '\' + $username + ' /SQLSVCPASSWORD='+$password+' /AGTSVCPASSWORD='+$password+' /SAPWD='+$password+'" ;
                Invoke-Expression $cmd'
            TestScript = '($sqlInstances = gwmi win32_service -computerName localhost | 
                ? { $_.Name -match "mssql*" -and $_.PathName -match "sqlservr.exe" } | 
                % { $_.Caption }) -ne $null -and $sqlInstances -gt 0'
            GetScript = '$sqlInstances = gwmi win32_service -computerName localhost | 
                ? { $_.Name -match "mssql*" -and $_.PathName -match "sqlservr.exe" } | % { $_.Caption } ;
                $res = $sqlInstances -ne $null -and $sqlInstances -gt 0 ;
                $vals = @{Installed = $res;InstanceCount = $sqlInstances.count} ;
                $vals'
            DependsOn = @("[Script]MountISO","[Script]ConfigurationFile")
        }

        # Dismount ISO
        Script DismountISO
        {
            setSCript = 'Dismount-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso'
            TestScript = '(!((Get-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso).Attached))'
            GetScript = 'if((Get-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso).Attached){return @("Absent")}else{return @("Present")}'
            DependsOn = "[Script]SQLServerInstallation"
        }

        Script sqlfile
        {
            setSCript = '
                $source = "'+$SQLDatabaseFileUri+'" ;
                $destination = "c:\sources\database.sql" ;
                (new-object system.net.webclient).DownloadFile($source,$destination)'
            TestScript = 'Test-Path "c:\sources\database.sql"'
            GetScript = 'if (Test-Path "c:\sources\database.sql"){return @("Present")}else{return @("Absent")}'
            DependsOn = "[Script]SQLServerInstallation"
        }

        Script SetSqlPs
        {
            setSCript = 'Import-Module "C:\Program Files (x86)\Microsoft SQL Server\110\Tools\PowerShell\Modules\SQLPS\SQLPS.psd1"'
            TestScript = 'if (Get-Module SqlPs){return $True}else{return $False}'
            GetScript = 'if (Get-Module SqlPs){@("Present")}else{@("Absent")}'
            DependsOn = "[Script]SQLServerInstallation"
        }
         
        # Dismount ISO
        Script CreateDB
        {
            setSCript = 'Invoke-Sqlcmd -InputFile "C:\sources\database.sql" -ServerInstance "." -ErrorAction "Stop" `
                -Password P@ssw0rd.1 -Username sa -Verbose -Variable databaseName=' + $databaseName + ' -QueryTimeout 1800'
            TestScript = '((Invoke-SQLCmd -Query "sp_databases" -Database master -ServerInstance "." -Password P@ssw0rd.1 -Username sa).DATABASE_NAME -contains "' + $databaseName + '")'
            GetScript = 'Invoke-SQLCmd -Query "sp_databases" -Database master -ServerInstance . -Password P@ssw0rd.1 -Username sa'
            DependsOn = @("[Script]SetSqlPs","[Script]sqlfile")
        }

        Script setSQLFireWallRule
        {
            setSCript = 'New-NetFirewallRule -DisplayName �SQL Server� -Direction Inbound �Protocol TCP �LocalPort 1433 -Action allow'
            TestScript = '((Get-NetFirewallRule).displayName -contains �SQL Server�)'
            GetScript = 'if((Get-NetFirewallRule).displayName -contains �SQL Server�){@("Present")}else{@("Absent")}'
        }
    }
}

configuration SQLServer 
{ 
 Param (
        [Parameter(Mandatory = $true)][string]$username,
        [Parameter(Mandatory = $true)][String]$password,
        [Parameter(Mandatory = $true)][string]$databaseName,
        [Parameter(Mandatory = $true)][string]$adDomainName,
        [Parameter(Mandatory = $true)][string]$SQLSetupConfigurationFileUri,
        [Parameter(Mandatory = $true)][string]$SQLServerISOUri,
        [Parameter(Mandatory = $true)][string]$SQLDatabaseFileUri
    )

    Import-DscResource -ModuleName xComputerManagement,xSQLServer,xPSDesiredStateConfiguration, xDatabase

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${adDomainName}\$([Environment]::UserName)", `
        (convertto-securestring "' + $password + '" -asplaintext -force))
    [string]$computerName = [Environment]::MachineName
    [string]$ISOFile = "c:\sources\SQLFULL_ENU.iso"

    Node "localhost"
    {
        # restart the node as soon as the configuration has been completely applies, without further warning
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        
        # Disable Automatic Update
        Registry UpdateTurnOff
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
            ValueName = "NoAutoUpdate"
            ValueData = "1"
            ValueType = "DWORD"

        }
        
        # Add computer to Active Directory
        xComputer JoinDomain 
        { 
            Name          = $computerName  
            DomainName    = $adDomainName 
            Credential    = $DomainCreds  # Credential to join to domain 
        }
        
        # create a source folder before upload configuration files and SQL Server ISO
        File SourcesFolder
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = "C:\sources"    
        }

        xRemoteFile SQLServerDownload
        {
            DestinationPath = $ISOFile
            Uri = $SQLServerISOUri
            DependsOn = @("[File]SourcesFolder","[xComputer]JoinDomain")
        }


        # Mount ISO
        Script MountISO
        {
            setSCript = 'Mount-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso ; start-sleep 10'
            TestScript = '(Get-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso).Attached'
            GetScript = '
                if((Get-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso).Attached){
                    return @("Present")
                }else{
                    return @("Absent")'
            DependsOn = "[xRemoteFile]SQLServerDownload"
        }

        xSQLServerSetup SQLServerSetup
        {
            SourcePath = ((get-Volume -DiskImage (Get-DiskImage -ImagePath "c:\sources\SQLFULL_ENU.iso")).DriveLetter) + ":" # REQUIRED - UNC path to the root of the source files for installation.
            SetupCredential = $DomainCreds # REQUIRED - Credential to be used to perform the installation.
            Features = "SQLENGINE,SSMS,ADV_SSMS" #: KEY - SQL features to be installed.
            InstanceName = "MSSQLSERVER" # KEY - SQL instance to be installed.
            SECURITYMODE="SQL"
            SAPwd = $password
            SQLSysAdminAccounts = "$ADdomainName\$username" #: Array of accounts to be made SQL administrators.
            <#
            SourceFolder: Folder within the source path containing the source files for installation.InstanceID: SQL instance ID, if different from InstanceName.
            PID: Product key for licensed installations.
            UpdateEnabled: Enabled updates during installation.
            UpdateSource: Source of updates to be applied during installation.
            SQMReporting: Enable customer experience reporting.
            ErrorReporting: Enable error reporting.
            InstallSharedDir: Installation path for shared SQL files.
            InstallSharedWOWDir: Installation path for x86 shared SQL files.
            InstanceDir: Installation path for SQL instance files.
            SQLSvcAccount: Service account for the SQL service.
            SQLSvcAccountUsername: Output username for the SQL service.
            AgtSvcAccount: Service account for the SQL Agent service.
            AgtSvcAccountUsername: Output username for the SQL Agent service.
            SQLCollation: Collation for SQL.
            InstallSQLDataDir: Root path for SQL database files.
            SQLUserDBDir: Path for SQL database files.
            SQLUserDBLogDir: Path for SQL log files.
            SQLTempDBDir: Path for SQL TempDB files.
            SQLTempDBLogDir: Path for SQL TempDB log files.
            SQLBackupDir: Path for SQL backup files.
            FTSvcAccount: Service account for the Full Text service.
            FTSvcAccountUsername: Output username for the Full Text service.
            RSSvcAccount: Service account for Reporting Services service.
            RSSvcAccountUsername: Output username for the Reporting Services service.
            ASSvcAccount: Service account for Analysus Services service.
            ASSvcAccountUsername: Output username for the Analysis Services service.
            ASCollation: Collation for Analysis Services.
            ASSysAdminAccounts: Array of accounts to be made Analysis Services admins.
            ASDataDir: Path for Analysis Services data files.
            ASLogDir: Path for Analysis Services log files.
            ASBackupDir: Path for Analysis Services backup files.
            ASTempDir: Path for Analysis Services temp files.
            ASConfigDir: Path for Analysis Services config.
            ISSvcAccount: Service account for Integration Services service.
            ISSvcAccountUsername: Output username for the Integration Services service.#>
            DependsOn = @("[Script]MountISO")
        }

        xRemoteFile sqlFileDownload
        {
            DestinationPath = "c:\sources\database.sql"
            Uri = $SQLDatabaseFileUri
            DependsOn = "[xSQLServerSetup]SQLServerSetup"
        }
         
        xDatabase CreateDB 
        { 
            Ensure = "Present"
            SqlServer = "localhost" 
            SqlServerVersion = "2012" 
            DatabaseName = $databaseName 
            Credentials = $DomainCreds 
            DependsOn = "[xRemoteFile]sqlFileDownload"
        }

        xSQLServerFirewall setSQLFireWallRule
        {
            Ensure = "Present"
            SourcePath = ((get-Volume -DiskImage (Get-DiskImage -ImagePath "c:\sources\SQLFULL_ENU.iso")).DriveLetter) + ":" # REQUIRED - UNC path to the root of the source files for installation.
            Features = "SQLENGINE" #: KEY - SQL features to be installed.
            InstanceName = "MSSQLSERVER" #(Key) SQL instance to enable firewall rules for.
    <#
    DatabaseEngineFirewall = $true #Is the firewall rule for the Database Engine enabled?
    SourceFolder: Folder within the source path containing the source files for installation.
    DatabaseEngineFirewall: Is the firewall rule for the Database Engine enabled?
    BrowserFirewall: Is the firewall rule for the Browser enabled?
    ReportingServicesFirewall: Is the firewall rule for Reporting Services enabled?
    AnalysisServicesFirewall: Is the firewall rule for Analysis Services enabled?
    IntegrationServicesFirewall: Is the firewall rule for the Integration Services enabled?#>
            DependsOn = "[xSQLServerSetup]SQLServerSetup"
        }

        # Dismount ISO
        Script DismountISO
        {
            setSCript = 'Dismount-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso'
            TestScript = '(!((Get-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso).Attached))'
            GetScript = 'if((Get-DiskImage -ImagePath c:\sources\SQLFULL_ENU.iso).Attached){return @("Absent")}else{return @("Present")}'
            DependsOn = "[xSQLServerFirewall]setSQLFireWallRule"
        }
    }
} 

#eoBootCampSQL -Node "localhost"
#start-DscConfiguration -PAth .\eoBootCampSQL -verbose -Wait -Force